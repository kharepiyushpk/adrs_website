// import { FaMapMarkerAlt, FaPhoneAlt, FaEnvelope, FaLinkedinIn, FaInstagram, FaGoogle, FaGithub } from 'react-icons/fa';

// const Footer = () => {
//   return (
//     <footer className="bg-[#1E293B] text-white pt-12 pb-8">
//       <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        
//         {/* Company Info */}
//         <div>
//           <img 
//             src="./src/assets/images/ADRS_logo.png" 
//             alt="ADRS Logo" 
//             className="h-20 w-20 filter invert brightness-200 contrast-200 drop-shadow-md mb-4"
//           />
//           <p className="flex items-start gap-2 mb-2">
//             <FaMapMarkerAlt className="mt-1 text-teal-400" />
//             Near Katangi Bypass, Karmeta Jabalpur, MP 482004
//           </p>
//           <p className="flex items-center gap-2 mb-2">
//             <FaPhoneAlt className="text-teal-400" /> 9201347033, 9076927464
//           </p>
//           <p className="flex items-center gap-2">
//             <FaEnvelope className="text-teal-400" /> adrstechnosoft@gmail.com
//           </p>
//         </div>

//         {/* Quick Links */}
//         <div>
//           <h3 className="text-xl font-semibold mb-4 border-b border-gray-600 pb-2">Quick Links</h3>
//           <ul className="space-y-2">
//             {[
//               'Website Development', 'Software Development', 'Graphic Designing', 'Mobile APP',
//               'Summer Internship', 'Digital Marketing', 'Privacy Policy'
//             ].map((link) => (
//               <li key={link}>
//                 <a href="/contact" className="hover:text-teal-300 transition duration-300">{link}</a>
//               </li>
//             ))}
//           </ul>
//         </div>

//         {/* Opening Hours */}
//         <div>
//           <h3 className="text-xl font-semibold mb-4 border-b border-gray-600 pb-2">Opening Hours</h3>
//           <ul className="space-y-1 text-sm">
//             {[
//               'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
//             ].map(day => (
//               <li key={day}>{day} 09:00 AM - 08:00 PM</li>
//             ))}
//             <li className="text-gray-400">Sunday: Closed</li>
//           </ul>
//         </div>

//         {/* Social Media */}
//         <div>
//           <h3 className="text-xl font-semibold mb-4 border-b border-gray-600 pb-2">Connect With Us</h3>
//           <div className="flex flex-col gap-4">
//             <a href="https://www.linkedin.com/company/adrs-technology/" className="flex items-center gap-3 hover:text-teal-300 transition">
//               <FaLinkedinIn className="bg-white text-[#1E293B] rounded-full p-2 text-3xl" /> LinkedIn
//             </a>
//             <a href="http://www.instagram.com/adrstechno" className="flex items-center gap-3 hover:text-teal-300 transition">
//               <FaInstagram className="bg-white text-[#1E293B] rounded-full p-2 text-3xl" /> Instagram
//             </a>
//             <a href="mailto:adrstechnosoft@gmail.com" className="flex items-center gap-3 hover:text-teal-300 transition">
//               <FaGoogle className="bg-white text-[#1E293B] rounded-full p-2 text-3xl" /> E-mail
//             </a>
//             <a href="https://github.com/adrstechno" className="flex items-center gap-3 hover:text-teal-300 transition">
//               <FaGithub className="bg-white text-[#1E293B] rounded-full p-2 text-3xl" /> GitHub
//             </a>
//           </div>
//         </div>
//       </div>

//       {/* Footer Bottom */}
//       <div className="border-t border-gray-600 mt-10 pt-6 text-center text-sm text-gray-400">
//         © 2024 ADRS PVT LTD — All rights reserved.
//       </div>
//     </footer>
//   );
// };

// export default Footer;
import { 
  FaTwitter, 
  FaGithub, 
  FaLinkedin, 
  FaFacebook, 

} from 'react-icons/fa';
const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Company Info */}
          <div className="space-y-4">
            <h5>
              <span className="text-blue-400 text-2xl font-bold">ADRS</span><br />Advanced Digital & Reliable Solutions
            </h5>
            <p className="text-gray-400">
              Innovating the future with cutting-edge technology solutions for your business.
            </p>
             <div className="flex space-x-4 icon_width">
              <a href="https://www.linkedin.com/company/adrs-technology/" className="text-gray-400 hover:text-white transition" aria-label="Twitter">
                <FaTwitter className="w-5 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition" aria-label="GitHub">
                <FaGithub className="w-5 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition" aria-label="LinkedIn">
                <FaLinkedin className="w-5 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition" aria-label="Facebook">
                <FaFacebook className="w-5 h-6" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold">Quick Links</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white transition">Home</a></li>
              <li><a href="#" className="hover:text-white transition">Services</a></li>
              <li><a href="#" className="hover:text-white transition">Products</a></li>
              <li><a href="#" className="hover:text-white transition">About us</a></li>
              <li><a href="#" className="hover:text-white transition">Contact</a></li>
            </ul>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold">Services</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white transition">Web Development</a></li>
              <li><a href="#" className="hover:text-white transition">Mobile App Development</a></li>
              <li><a href="#" className="hover:text-white transition">Software Development</a></li>
              <li><a href="#" className="hover:text-white transition">Digital Marketing</a></li>
              <li><a href="#" className="hover:text-white transition">Graphic Designing</a></li>
              
             
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold">Contact Us</h4>
            <address className="not-italic text-gray-400 space-y-2">
              <p> Near Katangi Bypass, Karmeta </p>
              <p>Jabalpur, MP 482004</p>
              <p>Email: info@techsolutions.com</p>
              <p>Phone: (123) 456-7890</p>
            </address>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} ADRS PVT LTD. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-gray-500 hover:text-white text-sm transition">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-white text-sm transition">Terms of Service</a>
            <a href="#" className="text-gray-500 hover:text-white text-sm transition">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;