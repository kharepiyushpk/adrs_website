import React from 'react'
import VerifyD from '../components/Verifyd'

const Verify = () => {
  return (
    <>
    <VerifyD/>
    
    
    </>
  )
}

export default Verify