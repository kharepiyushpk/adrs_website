import React from 'react'
import ContactD from '../components/contactd'

const Contact = () => {
  return (
    <>
    
    <ContactD/>
    
    </>
  )
}

export default Contact