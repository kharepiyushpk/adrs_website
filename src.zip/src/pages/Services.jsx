// import React from 'react'
import Servicesd from '../components/Servicesd'

const Services = () => {
  return (
    <>
    <Servicesd/>
    </>
  )
}

export default Services