import React from 'react'
import OurMission from '../components/OurMissiond'

const Our_Mission = () => {
  return (
    <>
    < OurMission />
    
    </>
  )
}

export default Our_Mission