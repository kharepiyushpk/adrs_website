import React from 'react'
import Registrationd from '../components/Registrationdd'
const Registration = () => {
  return (
    <>   
    
    <Registrationd/>
    </>
  )
}

export default Registration