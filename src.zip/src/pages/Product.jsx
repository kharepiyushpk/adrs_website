// import React from 'react'
import Productt from '../components/Productd'
const Product = () => {
  return (
    <>
    
    
    <Productt/>
    </>  )
}

export default Product