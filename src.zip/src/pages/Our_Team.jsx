import React from 'react'
import OurTeam from '../components/Our_teamd'

const Our_Team = () => {
  return (
    <>
    <OurTeam/>
    </>
  )
}

export default Our_Team