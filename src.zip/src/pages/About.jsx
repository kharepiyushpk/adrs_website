import React from 'react'
import AboutD from '../components/AboutD'

const About = () => {
  return (
   <>
   <AboutD/>
   </>
  )
}

export default About