// import React from 'react'
import Galleryd from '../components/Galleryd'
const Gallery = () => {
  return (
    <>
    
    <Galleryd/>
    
    </>
  )
}

export default Gallery